package com.example.data.firebase

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

/**
 * A "big gift" — sent by anyone, to anyone, in any one room — that should
 * be announced with a banner in EVERY room, the way BiG BOSS's gifts show
 * up everywhere. Written server-side by the sendRoomGift Cloud Function
 * whenever a gift's coin price crosses the broadcast threshold.
 */
data class GlobalGiftBroadcast(
    val id: String = "",
    val senderName: String = "",
    val recipientName: String = "",
    val giftName: String = "",
    val coinPrice: Long = 0L,
    val roomId: String = "",
    val roomTitle: String = "",
    val createdAtMillis: Long = 0L
) {
    /** e.g. "BiG BOSS sent Everyone a Happy Birthday gift! 🎉" */
    val bannerText: String
        get() = "$senderName sent $recipientName $giftName! 🎁✨"

    companion object {
        fun fromDocument(id: String, data: Map<String, Any?>): GlobalGiftBroadcast {
            val ts = data["createdAt"]
            val millis = when (ts) {
                is com.google.firebase.Timestamp -> ts.toDate().time
                is Number -> ts.toLong()
                else -> System.currentTimeMillis()
            }
            return GlobalGiftBroadcast(
                id = id,
                senderName = data["senderName"] as? String ?: "Someone",
                recipientName = data["recipientName"] as? String ?: "Someone",
                giftName = data["giftName"] as? String ?: "a gift",
                coinPrice = (data["coinPrice"] as? Number)?.toLong() ?: 0L,
                roomId = data["roomId"] as? String ?: "",
                roomTitle = data["roomTitle"] as? String ?: "",
                createdAtMillis = millis
            )
        }
    }
}

/**
 * Streams the newest big-gift broadcast as it's written. Every open room
 * screen collects this same flow and shows the banner for a few seconds —
 * that's what makes a big gift feel like it's "showing in every room".
 */
class GlobalGiftBroadcastService(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    private val tag = "GlobalGiftBroadcast"

    fun observeLatestBroadcast(): Flow<GlobalGiftBroadcast> = callbackFlow {
        val registration = firestore.collection("globalGiftBroadcasts")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(1)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(tag, "Broadcast listener error", error)
                    return@addSnapshotListener
                }
                val doc = snapshot?.documents?.firstOrNull() ?: return@addSnapshotListener
                val data = doc.data ?: return@addSnapshotListener
                trySend(GlobalGiftBroadcast.fromDocument(doc.id, data))
            }
        awaitClose { registration.remove() }
    }
}
