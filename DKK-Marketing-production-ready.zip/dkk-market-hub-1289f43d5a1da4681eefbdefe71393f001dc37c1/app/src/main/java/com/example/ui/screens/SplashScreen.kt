package com.example.ui.screens

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import com.example.R
import kotlinx.coroutines.delay

/**
 * Welcome / splash screen — the cute pastel "D.K.K. Marketing" shopfront
 * artwork the brand supplied, shown full-bleed. Auto-continues into the
 * app after a short pause, or immediately on tap.
 */
@Composable
fun SplashScreen(
    onContinue: () -> Unit
) {
    var hasContinued by remember { mutableStateOf(false) }

    fun goNext() {
        if (!hasContinued) {
            hasContinued = true
            onContinue()
        }
    }

    LaunchedEffect(Unit) {
        delay(2600)
        goNext()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { goNext() }
            .testTag("splash_continue_btn"),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_splash_welcome),
            contentDescription = "Welcome to D.K.K. Marketing",
            modifier = Modifier
                .fillMaxSize()
                .fillMaxWidth(),
            contentScale = ContentScale.Crop
        )
    }
}
