package com.example.data.firebase

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

data class UserWallet(
    val coinBalance: Long = 0L,
    val diamondBalance: Long = 0L,
    val purchasedThemeIds: Set<String> = emptySet(),
    val isProVip: Boolean = false
)

/**
 * Streams a user's Firestore profile (users/{uid}) in real time — this is
 * the source of truth for coin/diamond balances and purchased themes once
 * gifting/theme purchases go through the trusted Cloud Functions
 * (sendRoomGift, purchaseTheme), which write to this document server-side.
 */
class UserProfileService(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    private val tag = "UserProfileService"

    fun observeWallet(uid: String): Flow<UserWallet> = callbackFlow {
        val registration: ListenerRegistration = firestore.collection("users")
            .document(uid)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(tag, "Error listening to user $uid", error)
                    return@addSnapshotListener
                }
                val data = snapshot?.data ?: return@addSnapshotListener
                @Suppress("UNCHECKED_CAST")
                val themeIds = (data["purchasedThemeIds"] as? List<String>)?.toSet() ?: emptySet()
                trySend(
                    UserWallet(
                        coinBalance = (data["coinBalance"] as? Number)?.toLong() ?: 0L,
                        diamondBalance = (data["diamondBalance"] as? Number)?.toLong() ?: 0L,
                        purchasedThemeIds = themeIds,
                        isProVip = data["isProVip"] as? Boolean ?: false
                    )
                )
            }
        awaitClose { registration.remove() }
    }
}
