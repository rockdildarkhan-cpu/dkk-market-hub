package com.example.ui.screens

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.firebase.PhoneAuthService

private enum class OtpStep { ENTER_PHONE, ENTER_CODE }

/**
 * Real Firebase Phone Authentication gate. On success, hands back the
 * verified E.164 phone number and Firebase uid — the caller (MainActivity)
 * then proceeds to the existing AuthScreen for name/email/role, now
 * backed by a real signed-in Firebase user rather than a local-only demo
 * account.
 */
@Composable
fun PhoneOtpAuthScreen(
    phoneAuthService: PhoneAuthService,
    onVerified: (phoneE164: String, uid: String) -> Unit
) {
    val context = LocalContext.current
    var step by remember { mutableStateOf(OtpStep.ENTER_PHONE) }
    var phoneDigits by remember { mutableStateOf("") } // local part only, e.g. 03XXXXXXXXX
    var code by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    fun phoneE164(): String {
        val digitsOnly = phoneDigits.filter { it.isDigit() }
        // Accept "03XXXXXXXXX" (11 digits) or "3XXXXXXXXX" (10 digits) Pakistani mobile formats.
        val local = if (digitsOnly.startsWith("0")) digitsOnly.drop(1) else digitsOnly
        return "+92$local"
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070D1E)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = if (step == OtpStep.ENTER_PHONE) "Verify Your Phone" else "Enter the Code",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (step == OtpStep.ENTER_PHONE)
                    "We'll text you a 6-digit code to confirm it's really you."
                else
                    "Enter the code sent to ${phoneE164()}",
                color = Color(0xFFB8C1D9),
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(28.dp))

            if (step == OtpStep.ENTER_PHONE) {
                OutlinedTextField(
                    value = phoneDigits,
                    onValueChange = { if (it.length <= 11) phoneDigits = it },
                    label = { Text("Phone Number (03XXXXXXXXX)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    colors = otpFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                OutlinedTextField(
                    value = code,
                    onValueChange = { if (it.length <= 6) code = it },
                    label = { Text("6-digit code") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true,
                    colors = otpFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            errorMessage?.let {
                Spacer(modifier = Modifier.height(10.dp))
                Text(text = it, color = Color(0xFFEF4444), fontSize = 12.sp)
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    errorMessage = null
                    val activity = context as? Activity
                    if (activity == null) {
                        errorMessage = "Unable to start verification here."
                        return@Button
                    }

                    if (step == OtpStep.ENTER_PHONE) {
                        if (phoneDigits.filter { it.isDigit() }.length < 10) {
                            errorMessage = "Enter a valid phone number."
                            return@Button
                        }
                        isLoading = true
                        phoneAuthService.startVerification(
                            activity = activity,
                            phoneNumberE164 = phoneE164(),
                            onCodeSent = {
                                isLoading = false
                                step = OtpStep.ENTER_CODE
                            },
                            onAutoVerified = { uid ->
                                isLoading = false
                                onVerified(phoneE164(), uid)
                            },
                            onError = { msg ->
                                isLoading = false
                                errorMessage = msg
                            }
                        )
                    } else {
                        if (code.length < 6) {
                            errorMessage = "Enter the 6-digit code."
                            return@Button
                        }
                        isLoading = true
                        phoneAuthService.verifyCode(
                            code = code,
                            onSuccess = { uid ->
                                isLoading = false
                                onVerified(phoneE164(), uid)
                            },
                            onError = { msg ->
                                isLoading = false
                                errorMessage = msg
                            }
                        )
                    }
                },
                enabled = !isLoading,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F5C3F)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.height(20.dp), color = Color.White)
                } else {
                    Text(
                        if (step == OtpStep.ENTER_PHONE) "Send Code" else "Verify",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            if (step == OtpStep.ENTER_CODE) {
                Spacer(modifier = Modifier.height(12.dp))
                TextButton(onClick = {
                    step = OtpStep.ENTER_PHONE
                    code = ""
                    errorMessage = null
                }) {
                    Text("Change phone number", color = Color(0xFFD4AF37), fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun otpFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    focusedBorderColor = Color(0xFFD4AF37),
    unfocusedBorderColor = Color(0xFF334155),
    focusedLabelColor = Color(0xFFD4AF37),
    unfocusedLabelColor = Color(0xFF94A3B8),
    cursorColor = Color(0xFFD4AF37)
)
