package com.example.data.firebase

import android.app.Activity
import android.util.Log
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import java.util.concurrent.TimeUnit

sealed class PhoneAuthState {
    data object Idle : PhoneAuthState()
    data object SendingCode : PhoneAuthState()
    data class CodeSent(val verificationId: String) : PhoneAuthState()
    data object VerifyingCode : PhoneAuthState()
    data class Verified(val uid: String) : PhoneAuthState()
    data class Error(val message: String) : PhoneAuthState()
}

/**
 * Wraps FirebaseAuth's phone-number sign-in (send SMS OTP, verify the
 * 6-digit code the user types back). Must be started from an Activity
 * (required by PhoneAuthOptions for the reCAPTCHA/Play Integrity
 * fallback) — call `startVerification` from a Composable that has access
 * to the current Activity via LocalContext.
 *
 * IMPORTANT — before this works on a real device:
 *  1. Firebase Console -> Authentication -> Sign-in method -> Phone -> Enable.
 *  2. Firebase Console -> Project settings -> Your app -> add the SHA-1
 *     (and SHA-256) certificate fingerprint of BOTH your debug keystore
 *     and the release keystore (dkk-release-keystore.jks), then
 *     re-download google-services.json and replace app/google-services.json.
 *     Without this, phone auth silently falls back to a reCAPTCHA web
 *     view or fails outright on release builds.
 */
class PhoneAuthService(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    private val tag = "PhoneAuthService"
    private var resendToken: PhoneAuthProvider.ForceResendingToken? = null
    private var storedVerificationId: String? = null

    val currentUid: String? get() = auth.currentUser?.uid

    fun startVerification(
        activity: Activity,
        phoneNumberE164: String,
        onCodeSent: (verificationId: String) -> Unit,
        onAutoVerified: (uid: String) -> Unit,
        onError: (String) -> Unit
    ) {
        val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                // Android auto-read the SMS and verified instantly — sign in right away.
                signInWithCredential(credential, onAutoVerified, onError)
            }

            override fun onVerificationFailed(e: FirebaseException) {
                Log.e(tag, "Phone verification failed", e)
                onError(e.message ?: "Verification failed. Check the phone number and try again.")
            }

            override fun onCodeSent(
                verificationId: String,
                token: PhoneAuthProvider.ForceResendingToken
            ) {
                storedVerificationId = verificationId
                resendToken = token
                onCodeSent(verificationId)
            }
        }

        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phoneNumberE164)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(callbacks)
            .build()

        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    fun resendCode(
        activity: Activity,
        phoneNumberE164: String,
        onCodeSent: (verificationId: String) -> Unit,
        onAutoVerified: (uid: String) -> Unit,
        onError: (String) -> Unit
    ) {
        val token = resendToken
        if (token == null) {
            startVerification(activity, phoneNumberE164, onCodeSent, onAutoVerified, onError)
            return
        }

        val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                signInWithCredential(credential, onAutoVerified, onError)
            }

            override fun onVerificationFailed(e: FirebaseException) {
                onError(e.message ?: "Verification failed.")
            }

            override fun onCodeSent(
                verificationId: String,
                newToken: PhoneAuthProvider.ForceResendingToken
            ) {
                storedVerificationId = verificationId
                resendToken = newToken
                onCodeSent(verificationId)
            }
        }

        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phoneNumberE164)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(callbacks)
            .setForceResendingToken(token)
            .build()

        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    fun verifyCode(
        code: String,
        onSuccess: (uid: String) -> Unit,
        onError: (String) -> Unit
    ) {
        val verificationId = storedVerificationId
        if (verificationId == null) {
            onError("Session expired — please request a new code.")
            return
        }
        val credential = PhoneAuthProvider.getCredential(verificationId, code)
        signInWithCredential(credential, onSuccess, onError)
    }

    private fun signInWithCredential(
        credential: PhoneAuthCredential,
        onSuccess: (uid: String) -> Unit,
        onError: (String) -> Unit
    ) {
        auth.signInWithCredential(credential)
            .addOnSuccessListener { result ->
                val uid = result.user?.uid
                if (uid != null) onSuccess(uid) else onError("Sign-in failed — no user returned.")
            }
            .addOnFailureListener { e ->
                Log.e(tag, "signInWithCredential failed", e)
                onError(e.message ?: "Incorrect code. Please try again.")
            }
    }

    fun signOut() {
        auth.signOut()
        storedVerificationId = null
        resendToken = null
    }
}
