package com.example.data.model

/**
 * A selectable background "skin" for a Live Audio Room (background art +
 * accent color). "Cosmic Earth" is the free default every host starts
 * with; the rest are paid — unlocked once with Diamonds via the
 * purchaseTheme Cloud Function, then owned forever.
 */
data class RoomTheme(
    val id: String,
    val displayName: String,
    val drawableName: String,
    val accentColorHex: Long,
    val priceDiamonds: Long = 0L
) {
    val isFree: Boolean get() = priceDiamonds <= 0L
}

object RoomThemes {
    /** Free default theme every host has from the start. */
    val COSMIC_EARTH = RoomTheme(
        id = "cosmic_earth",
        displayName = "Cosmic Earth",
        drawableName = "img_theme_cosmic_earth",
        accentColorHex = 0xFF3B82F6,
        priceDiamonds = 0L
    )

    /** Paid theme — 10,000 Diamonds. */
    val MIDNIGHT_GOLD_PALACE = RoomTheme(
        id = "midnight_gold_palace",
        displayName = "Midnight Gold Palace",
        // TODO: replace with real midnight/gold palace background art.
        // Using the existing cosmic-earth art as a placeholder so the app
        // still compiles/runs until that artwork is supplied.
        drawableName = "img_theme_cosmic_earth",
        accentColorHex = 0xFFD4AF37,
        priceDiamonds = 10_000L
    )

    /**
     * Paid theme — 15,000 Diamonds. The "Love Connection" heart-frame
     * theme: a warm, cozy couple portrait, matching the reference art.
     */
    val LOVE_CONNECTION = RoomTheme(
        id = "love_connection",
        displayName = "Love Connection",
        drawableName = "img_theme_love_connection",
        accentColorHex = 0xFFEC4899,
        priceDiamonds = 15_000L
    )

    /** All themes a host can pick from, free one first. */
    val ALL: List<RoomTheme> = listOf(COSMIC_EARTH, MIDNIGHT_GOLD_PALACE, LOVE_CONNECTION)

    fun byId(id: String?): RoomTheme = ALL.firstOrNull { it.id == id } ?: COSMIC_EARTH

    /** A user always owns the free theme, plus whatever they've purchased. */
    fun isOwned(theme: RoomTheme, purchasedThemeIds: Collection<String>): Boolean =
        theme.isFree || theme.id in purchasedThemeIds
}
