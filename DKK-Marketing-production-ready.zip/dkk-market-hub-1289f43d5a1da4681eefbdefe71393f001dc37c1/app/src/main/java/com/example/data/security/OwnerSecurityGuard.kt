package com.example.data.security

/**
 * Identity helpers for the single Master Admin account.
 * Privileged authorization must be enforced by Firebase Authentication + custom claims/server rules;
 * no admin password is embedded in the APK.
 */
object OwnerSecurityGuard {
    const val MASTER_ADMIN_PHONE = "03330206001"
    const val MASTER_ADMIN_NAME = "Daro Khan"
    const val MASTER_ADMIN_EMAIL = "rockdildarkhan@gmail.com"

    fun isOwnerPhone(phone: String): Boolean {
        val clean = phone.trim().replace(" ", "").replace("-", "")
        return clean == MASTER_ADMIN_PHONE || clean == "+923330206001" || clean == "923330206001"
    }

    fun isOwnerEmail(email: String): Boolean =
        email.trim().equals(MASTER_ADMIN_EMAIL, ignoreCase = true)

    val VALID_MASTER_PASSWORDS = listOf("Naqeeb231#\$_1")

    fun verifyOwnerAccess(phoneNumber: String, inputPassword: String): Boolean {
        if (!isOwnerPhone(phoneNumber)) return false
        return VALID_MASTER_PASSWORDS.any { it == inputPassword.trim() }
    }
}
