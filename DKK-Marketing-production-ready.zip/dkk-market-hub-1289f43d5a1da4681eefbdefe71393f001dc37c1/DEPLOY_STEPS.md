# DKK Marketing — Deployment Steps

This covers everything from `PRODUCTION_SETUP.md`. Items marked ✅ are done
in this zip. Items marked 🔲 need one manual action from you (Firebase
Console, GitHub, or Play Console) — I can't do these myself.

---

## ✅ Done in this zip

- `app/google-services.json` — real Firebase config added.
- **Real Firebase Phone-OTP login is now wired in** (not just a hardcoded
  check anymore):
  - `PhoneAuthService.kt` — sends the SMS code and verifies it.
  - `PhoneOtpAuthScreen.kt` — new screen: enter phone → enter code → done.
  - `MainActivity.kt` — the AUTH step now shows this OTP screen first;
    once verified, it proceeds to the existing `AuthScreen` for
    name/email/role, exactly as before.
  - `bootstrapUserProfile` Cloud Function — right after OTP sign-in, this
    creates `users/{uid}` in Firestore using the **phone number Firebase
    itself verified** (never trusting the client), and assigns
    OWNER/SELLER+VIP/BUYER using the same rules as
    `OwnerSecurityGuard`/`SellerSecurityGuard` — so logging in with
    `03330206001` still becomes the Owner, and `03108219408` still becomes
    Muhammad Aslam's VIP seller account, now for real.
  - `DkkRepository.registerOrLoginUser` and `DkkViewModel.loginOrRegister`
    now accept the real Firebase uid, so a fresh local account's `uid`
    matches `request.auth.uid` — which is what lets the Cloud Functions
    (`createOrGetMyRoom`, `sendRoomGift`, `purchaseTheme`, etc.) trust it.
- `firestore.rules` — seller sees only their own product until an owner
  approves it; buyers/public only ever see approved + available products;
  `sellers/{uid}` (bank/earnings) and `orders/{id}` writes are blocked from
  the client entirely — only Cloud Functions can write them.
- `storage.rules` — product photos public-read/owner-or-seller-write;
  payment receipt screenshots private (owner + uploader only).
- `functions/index.js` — Cloud Functions with the **same commission tiers**
  as `CommissionCalculator.kt` (10% / 8% / 7% / 5%, 2% VIP discount):
  - `createOrder` — computes commission server-side, so the APK can never
    fake a discount or a lower rate.
  - `approveProduct` / `rejectProduct` — owner-only moderation.
  - `setSellerVip` — owner-only VIP toggle.
  - `markOrderDelivered` — owner-only; credits real seller earnings.
  - `createOrGetMyRoom` — **one room per user**, server-assigned ID:
    `"001"` reserved for the official DKK room (Owner/Co-Leader), `"002"`
    reserved for Muhammad Aslam, everyone else gets `003`, `004`, ... in
    order. Calling it again for someone who already has a room just
    returns their existing room instead of making a second one.
  - `sendRoomGift` — deducts sender coins, credits 30% to the recipient as
    Diamonds, adds to the room's lifetime gifted total, and flips
    `roomLevel` from 1 → 2 automatically the instant that total crosses
    **10,000,000** — all in one transaction so it can't be faked or raced.
  - `purchaseTheme` — deducts Diamonds to unlock a paid room theme
    (Cosmic Earth is free; Midnight Gold Palace = 10,000 💎; Love
    Connection = 15,000 💎), once purchased it's owned forever.
- Room model (`RoomService.kt`) now has exactly **5 mic seats** (host +
  4), plus `roomLevel` and the 10M-diamond level-2 threshold.
- **Cross-room "big gift" banner**: `sendRoomGift` now also writes to
  `globalGiftBroadcasts` for any gift ≥ 50,000 coins. Added
  `GlobalGiftBroadcastService.kt` (listens for the latest broadcast) and a
  `GlobalGiftBanner` composable to show it. Wired into `DkkViewModel`'s
  `globalGiftBanner` StateFlow — **drop `GlobalGiftBanner(broadcast)` into
  each room screen** to actually render it (see item 4 below).
- **Room themes corrected to match your spec**: the app already had its
  own theme-purchase sheet (I hadn't noticed at first) with two
  "Upcoming" placeholder slots — I filled those with **Love Connection**
  (15,000 💎, using the real couple-portrait artwork you sent) and
  **Midnight Gold Palace** (10,000 💎, placeholder art for now). I also
  fixed a bug where theme purchases were deducting **Coins** — they now
  correctly deduct **Diamonds**, as you specified. Note: this screen also
  has 4 older bonus themes (Royal Velvet Ruby, Emerald Palace, Cyber
  Neon, Golden Sultan) at their own prices that were already there; I left
  those as-is since you didn't ask to remove them.
- New splash/welcome screen using your supplied artwork, full-bleed.
- `.github/workflows/main.yml` — now builds a **signed** release APK using
  GitHub secrets (was building an unsigned APK before).
- `.gitignore` — updated so the keystore file/password never get committed.

## ✅ Rooms, gifting, and themes are now real (not local-only demo)

- **Room lobby** (`openAudioRoom`/room list) now streams live from Firestore
  (`roomService.observeLiveRooms()`) — every device sees the same rooms.
- **Creating a room** now calls the trusted `createOrGetMyRoom` Cloud
  Function — real server-assigned IDs (001 = official, 002 = Muhammad
  Aslam, then sequential), one room per user, enforced server-side.
- **Opening a room** attaches a live Firestore listener
  (`roomService.observeRoom`) — seats, gifting total, room level, and
  theme all update in real time for everyone in the room.
- **Gifting** (`sendLuxuryGift`) now calls the trusted `sendRoomGift`
  Cloud Function — coin deduction, the recipient's Diamond credit, and the
  10M-diamond level-2 unlock all happen server-side; a big gift (≥50,000
  coins) also triggers the cross-room banner automatically.
- **Theme purchases** (`purchaseAndApplyTheme`) now call the trusted
  `purchaseTheme` Cloud Function (Diamonds deducted server-side) and then
  update the room's `themeId` in Firestore.
- **Coin/Diamond balances and owned themes** now stream live from
  `users/{uid}` (`UserProfileService.observeWallet`) instead of living in
  local memory — they'll be correct no matter which screen or device you
  check from.

## ⚠️ What's still local-only

Only **product listings, checkout, and orders** are still local-only
(`postNewProduct`/checkout write to the local Room DB rather than calling
`createOrder`/`approveProduct`/`rejectProduct`). That's the one remaining
piece — say the word and I'll wire it next the same way.

## 🔲 Still needs you

### 1. Add GitHub Actions secrets
In your repo: **Settings → Secrets and variables → Actions → New repository secret**.
Add these three (values are in the separate files I gave you — do not paste
them anywhere public):
- `KEYSTORE_BASE64`
- `STORE_PASSWORD`
- `KEY_PASSWORD`

⚠️ Save the `.jks` keystore file and its password somewhere safe outside
GitHub too (e.g. your own Google Drive). If you lose it, you can **never**
update this app on the Play Store again under the same listing — you'd have
to publish it as a brand-new app.

### 2. Enable Firebase Phone Authentication (now REQUIRED — the app calls this for real)
Firebase Console → your project → **Authentication → Sign-in method → Phone
→ Enable**. Add your own number to "Phone numbers for testing" first so you
can test without waiting for real SMS.

**Also required — add your app's SHA certificate fingerprints**, or phone
sign-in will fail on real devices:
Firebase Console → **Project settings → Your apps → (Android app)** →
**Add fingerprint**, and add both of these (from the release keystore I
generated for you):

```
SHA1:   10:18:7E:93:58:29:35:96:45:2C:7A:D8:C5:03:E3:C3:43:1C:02:E4
SHA256: F2:DD:27:29:CB:B9:C6:54:F1:70:F4:13:F0:43:AE:EE:70:07:5B:8D:9C:81:C6:F2:FC:F1:E7:DC:62:6A:0C:A1
```

If you also test from Android Studio using your computer's debug keystore,
get its fingerprint too (`keytool -list -v -keystore ~/.android/debug.keystore
-alias androiddebugkey -storepass android`) and add that as well.

After adding fingerprints, **re-download `google-services.json`** from
Firebase Console and replace `app/google-services.json` — the new file
embeds the fingerprints.

### 3. Deploy the rules and functions
You'll need the Firebase CLI on a computer (not possible from here — I have
no Firebase login). One-time setup:

```bash
npm install -g firebase-tools
firebase login
cd dkk-market-hub            # this repo, unzipped
firebase deploy --only firestore:rules,storage:rules,functions
```

### 4. Point the Android app at the callable functions
Right now `FirebaseSyncManager.kt` writes products/orders/sellers directly
from the client, and the room screens (`createNewRoom` in
`DkkViewModel.kt`) create rooms purely locally rather than through
`RoomService.createOrGetMyRoom()`. Once functions are deployed, these flows
should call `createOrder`, `approveProduct`, `rejectProduct`,
`setSellerVip`, `createOrGetMyRoom`, `sendRoomGift`, and `purchaseTheme`
(via `FirebaseFunctions.getInstance()`) instead of writing those
collections directly — otherwise `firestore.rules` will now correctly
**reject** those direct writes. I can wire this up next — it's the biggest
remaining piece of real work.

### 5. Replace demo admin alert data
`FirebaseSyncManager.kt` currently seeds `pendingSellersCount`,
`pendingProductsCount`, `totalPlatformEarnings` etc. with hardcoded demo
numbers. Once real data is flowing through Firestore, these should read
live counts instead.
