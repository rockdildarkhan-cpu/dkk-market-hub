# DKK Marketing — Production Setup

This build removes automatic startup login and public Quick Demo Persona access.

## Required before live release
1. Add the real Firebase `google-services.json` for applicationId `com.dkk.marketing`.
2. Enable Firebase Authentication (Phone provider) and configure SMS/anti-abuse settings.
3. Deploy Firestore Security Rules so seller financial data is owner-only and product publication is owner-controlled.
4. Move commission/VIP/role authorization to trusted server-side code (Firebase Cloud Functions/custom claims); do not trust APK-side role checks.
5. Configure Firebase Storage rules for product media and payment receipts.
6. Replace demo/simulated admin alert data with Firestore-backed streams.
7. Configure release signing variables (`KEYSTORE_PATH`, `STORE_PASSWORD`, `KEY_PASSWORD`).

The current source is a safer production-oriented intermediate build, but it is not claimed to be fully live until the Firebase backend is configured and rules are deployed.
