/**
 * DKK Marketing — Cloud Functions
 *
 * This is the "trusted server-side code" that PRODUCTION_SETUP.md asks for:
 * commission math, VIP discounts, and role changes must never be trusted
 * from the Android client alone. These callable functions mirror
 * CommissionCalculator.kt exactly, but run with the Admin SDK, so the
 * Firestore rules can safely block direct client writes to orders/sellers.
 *
 * Deploy with:
 *   firebase deploy --only functions
 */

const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { onDocumentUpdated } = require("firebase-functions/v2/firestore");
const admin = require("firebase-admin");

admin.initializeApp();
const db = admin.firestore();

// ---------------------------------------------------------------------------
// Default commission config (mirrors GlobalCommissionConfig.kt defaults).
// The live values are read from Firestore config/commission if present,
// so the owner can tune them from the app without a redeploy.
// ---------------------------------------------------------------------------
const DEFAULT_CONFIG = {
  isTieredCommissionEnabled: true,
  defaultFlatCommissionRatePercent: 8.0,
  tier1MaxAmount: 10000.0,
  tier1RatePercent: 10.0,
  tier2MaxAmount: 20000.0,
  tier2RatePercent: 8.0,
  tier3MaxAmount: 35000.0,
  tier3RatePercent: 7.0,
  tier4RatePercent: 5.0,
  isVipDiscountEnabled: true,
  vipDiscountPercent: 2.0,
  isPlatformFeeEnabled: false,
  fixedPlatformFeePkr: 50.0,
};

async function getCommissionConfig() {
  const snap = await db.doc("config/commission").get();
  if (!snap.exists) return DEFAULT_CONFIG;
  return { ...DEFAULT_CONFIG, ...snap.data() };
}

function getCommissionRate(config, orderAmount, isVipSeller) {
  let baseRate;
  if (config.isTieredCommissionEnabled) {
    if (orderAmount <= config.tier1MaxAmount) baseRate = config.tier1RatePercent / 100;
    else if (orderAmount <= config.tier2MaxAmount) baseRate = config.tier2RatePercent / 100;
    else if (orderAmount <= config.tier3MaxAmount) baseRate = config.tier3RatePercent / 100;
    else baseRate = config.tier4RatePercent / 100;
  } else {
    baseRate = config.defaultFlatCommissionRatePercent / 100;
  }
  const discount = isVipSeller && config.isVipDiscountEnabled ? config.vipDiscountPercent / 100 : 0;
  return Math.max(baseRate - discount, 0.01);
}

function calculateCommission(config, orderAmount, isVipSeller) {
  const rate = getCommissionRate(config, orderAmount, isVipSeller);
  const rateCommission = orderAmount * rate;
  const platformFee = config.isPlatformFeeEnabled ? config.fixedPlatformFeePkr : 0;
  return {
    commissionAmount: rateCommission + platformFee,
    commissionRatePercent: rate * 100,
  };
}

async function requireAuth(request) {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Sign in required.");
  }
  return request.auth.uid;
}

async function requireOwner(request) {
  const uid = await requireAuth(request);
  const userSnap = await db.doc(`users/${uid}`).get();
  if (!userSnap.exists || userSnap.data().role !== "OWNER") {
    throw new HttpsError("permission-denied", "Owner only.");
  }
  return uid;
}

// ---------------------------------------------------------------------------
// createOrder — the ONLY way an order should be written. Computes commission
// server-side from the live product price and the seller's real VIP status,
// so a tampered APK can never fake a discount or a fake commission.
// ---------------------------------------------------------------------------
exports.createOrder = onCall(async (request) => {
  const buyerUid = await requireAuth(request);
  const { productId, paymentMethod, paymentRef } = request.data || {};

  if (!productId) {
    throw new HttpsError("invalid-argument", "productId is required.");
  }

  const productSnap = await db.doc(`products/${productId}`).get();
  if (!productSnap.exists) {
    throw new HttpsError("not-found", "Product not found.");
  }
  const product = productSnap.data();

  if (product.status !== "APPROVED" || product.isAvailable !== true) {
    throw new HttpsError("failed-precondition", "This product is not available for order.");
  }

  const sellerSnap = await db.doc(`sellers/${product.sellerId}`).get();
  const sellerUserSnap = await db.doc(`users/${product.sellerId}`).get();
  const isVipSeller = sellerUserSnap.exists ? !!sellerUserSnap.data().isProVip : false;

  const config = await getCommissionConfig();
  const { commissionAmount, commissionRatePercent } = calculateCommission(
    config,
    product.price,
    isVipSeller
  );

  const orderRef = db.collection("orders").doc();
  const order = {
    orderId: orderRef.id,
    buyerId: buyerUid,
    sellerId: product.sellerId,
    sellerName: product.sellerName,
    productId,
    productTitle: product.title,
    orderAmount: product.price,
    commissionAmount,
    commissionRatePercent,
    sellerEarnings: product.price - commissionAmount,
    paymentMethod: paymentMethod || "Easypaisa",
    paymentRef: paymentRef || "",
    deliveryStatus: "PENDING",
    otpVerified: false,
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
  };

  await orderRef.set(order);
  return { orderId: orderRef.id, commissionAmount, commissionRatePercent };
});

// ---------------------------------------------------------------------------
// bootstrapUserProfile — call this immediately after a successful phone-OTP
// sign-in. Creates (or updates the phone on) users/{uid} in Firestore,
// using the phone number Firebase itself verified via SMS
// (request.auth.token.phone_number) — never a client-supplied string, so
// it can't be spoofed. Mirrors the same role rules as
// OwnerSecurityGuard/SellerSecurityGuard.kt: the master admin's number
// becomes OWNER, Muhammad Aslam's number becomes a VIP SELLER, everyone
// else defaults to BUYER. Safe to call on every login — it never
// downgrades an existing role.
// ---------------------------------------------------------------------------
const MASTER_ADMIN_PHONE = "+923330206001";
// (MUHAMMAD_ASLAM_PHONE already declared above, near allocateRoomId.)

exports.bootstrapUserProfile = onCall(async (request) => {
  const uid = await requireAuth(request);
  const verifiedPhone = request.auth.token.phone_number || null;
  const { fallbackName, fallbackEmail } = request.data || {};

  const userRef = db.doc(`users/${uid}`);

  return db.runTransaction(async (tx) => {
    const snap = await tx.get(userRef);

    if (snap.exists) {
      // Already bootstrapped — just make sure the verified phone is on file.
      if (verifiedPhone && snap.data().phoneNumber !== verifiedPhone) {
        tx.set(userRef, { phoneNumber: verifiedPhone }, { merge: true });
      }
      return { uid, role: snap.data().role, isNew: false };
    }

    let role = "BUYER";
    let isProVip = false;
    let name = fallbackName || "DKK User";

    if (verifiedPhone === MASTER_ADMIN_PHONE) {
      role = "OWNER";
      name = "Daro Khan (DKK Owner)";
    } else if (verifiedPhone === MUHAMMAD_ASLAM_PHONE) {
      role = "SELLER";
      isProVip = true;
      name = "Muhammad Aslam (Universe Jewellery)";
    }

    tx.set(userRef, {
      phoneNumber: verifiedPhone,
      name,
      email: fallbackEmail || "",
      role,
      isProVip,
      diamondBalance: 0,
      coinBalance: 0,
      purchasedThemeIds: [],
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    return { uid, role, isNew: true };
  });
});

// ---------------------------------------------------------------------------
// Rooms: one room per user, server-assigned sequential IDs, 5 mic seats,
// and trusted diamond-gifting math (so a level-up can't be faked client-side).
// ---------------------------------------------------------------------------
const ROOM_LEVEL_2_THRESHOLD = 10_000_000; // diamonds/coins gifted in a room
const MUHAMMAD_ASLAM_PHONE = "+923108219408";

async function allocateRoomId(uid) {
  return db.runTransaction(async (tx) => {
    const userRef = db.doc(`users/${uid}`);
    const userSnap = await tx.get(userRef);
    const userData = userSnap.exists ? userSnap.data() : {};

    // Idempotent: if this user already has a room, just return it.
    if (userData.roomId) {
      return { roomId: userData.roomId, isNew: false, userData };
    }

    // Reserved IDs, each only ever handed out once.
    const reserved =
      userData.role === "OWNER" || userData.role === "CO_LEADER"
        ? "001"
        : userData.phoneNumber === MUHAMMAD_ASLAM_PHONE
        ? "002"
        : null;

    let roomId;
    if (reserved) {
      const reservedRoomSnap = await tx.get(db.doc(`rooms/${reserved}`));
      if (!reservedRoomSnap.exists) {
        roomId = reserved;
      }
    }

    if (!roomId) {
      const counterRef = db.doc("config/roomIdCounter");
      const counterSnap = await tx.get(counterRef);
      // Start the general counter at 3 so 001/002 stay reserved even if
      // this runs before either of them has signed up yet.
      const next = counterSnap.exists ? (counterSnap.data().next || 3) : 3;
      roomId = String(next).padStart(3, "0");
      tx.set(counterRef, { next: next + 1 }, { merge: true });
    }

    tx.set(userRef, { roomId }, { merge: true });
    return { roomId, isNew: true, userData };
  });
}

exports.createOrGetMyRoom = onCall(async (request) => {
  const uid = await requireAuth(request);
  const { title, hostName, hostAvatar } = request.data || {};

  const { roomId, isNew, userData } = await allocateRoomId(uid);

  if (isNew) {
    const seats = {};
    for (let i = 0; i < 5; i++) {
      seats[String(i)] =
        i === 0
          ? {
              seatIndex: 0,
              occupantUid: uid,
              occupantName: hostName || userData.name || "Host",
              occupantAvatar: hostAvatar || userData.profilePicture || "",
              isMuted: false,
              isTalking: false,
              isLocked: false,
              giftScore: 0,
              joinedAt: Date.now(),
            }
          : { seatIndex: i, occupantUid: null, isMuted: true, isLocked: false, giftScore: 0 };
    }

    await db.doc(`rooms/${roomId}`).set({
      roomId,
      title: title || (roomId === "001" ? "DKK Marketing Official" : `${hostName || "Host"}'s Room`),
      hostUid: uid,
      hostName: hostName || userData.name || "Host",
      hostAvatar: hostAvatar || userData.profilePicture || "",
      status: "LIVE",
      listenerCount: 1,
      seats,
      totalCoinsGifted: 0,
      roomLevel: 1,
      themeId: "cosmic_earth",
      announcement: "Welcome to D.K.K. Live Audio! Please respect everyone and chat decently. 🎙️✨",
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  }

  return { roomId, isNew };
});

// sendRoomGift — the trusted path for diamond gifting. Deducts the sender's
// coin balance, credits the recipient's diamond balance (30% of coin
// price), adds to the room's lifetime gifted total, and flips roomLevel to
// 2 the moment that total crosses 10,000,000 — all in one transaction so it
// can't be raced or spoofed from a modified APK.
// A gift at or above this coin price is "big" — it gets broadcast to every
// room, not just the one it was sent in (matches BiG BOSS-style
// cross-room announcements).
const GLOBAL_BROADCAST_COIN_THRESHOLD = 50000;

exports.sendRoomGift = onCall(async (request) => {
  const senderUid = await requireAuth(request);
  const { roomId, recipientUid, giftName, coinPrice } = request.data || {};

  if (!roomId || !recipientUid || !coinPrice || coinPrice <= 0) {
    throw new HttpsError("invalid-argument", "roomId, recipientUid and a positive coinPrice are required.");
  }

  const result = await db.runTransaction(async (tx) => {
    const senderRef = db.doc(`users/${senderUid}`);
    const recipientRef = db.doc(`users/${recipientUid}`);
    const roomRef = db.doc(`rooms/${roomId}`);

    const [senderSnap, recipientSnap, roomSnap] = await Promise.all([
      tx.get(senderRef),
      tx.get(recipientRef),
      tx.get(roomRef),
    ]);

    if (!roomSnap.exists) throw new HttpsError("not-found", "Room not found.");

    const senderCoinBalance = (senderSnap.exists && senderSnap.data().coinBalance) || 0;
    if (senderCoinBalance < coinPrice) {
      throw new HttpsError("failed-precondition", "Not enough coins.");
    }

    const diamondsEarned = Math.max(Math.floor(coinPrice * 0.3), 1);
    const previousTotal = roomSnap.data().totalCoinsGifted || 0;
    const newTotal = previousTotal + coinPrice;
    const leveledUp = previousTotal < ROOM_LEVEL_2_THRESHOLD && newTotal >= ROOM_LEVEL_2_THRESHOLD;
    const newLevel = newTotal >= ROOM_LEVEL_2_THRESHOLD ? 2 : roomSnap.data().roomLevel || 1;

    tx.update(senderRef, { coinBalance: senderCoinBalance - coinPrice });
    tx.set(
      recipientRef,
      { diamondBalance: admin.firestore.FieldValue.increment(diamondsEarned) },
      { merge: true }
    );
    tx.update(roomRef, { totalCoinsGifted: newTotal, roomLevel: newLevel });

    return {
      diamondsEarned,
      newTotal,
      roomLevel: newLevel,
      leveledUp,
      senderName: (senderSnap.exists && senderSnap.data().name) || "Someone",
      recipientName: (recipientSnap.exists && recipientSnap.data().name) || "Someone",
      roomTitle: roomSnap.data().title || "",
    };
  });

  // Outside the transaction: fire a cross-room broadcast for big gifts.
  if (coinPrice >= GLOBAL_BROADCAST_COIN_THRESHOLD) {
    await db.collection("globalGiftBroadcasts").add({
      senderUid,
      senderName: result.senderName,
      recipientUid,
      recipientName: result.recipientName,
      giftName: giftName || "a gift",
      coinPrice,
      roomId,
      roomTitle: result.roomTitle,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  }

  return result;
});

// ---------------------------------------------------------------------------
// purchaseTheme — trusted Diamond deduction to unlock a paid room theme.
// Mirrors app/.../data/model/RoomThemes.kt: cosmic_earth is free by
// default; midnight_gold_palace costs 10,000 Diamonds; love_connection
// costs 15,000 Diamonds. Once purchased, a theme is owned forever.
// ---------------------------------------------------------------------------
const THEME_PRICES_DIAMONDS = {
  cosmic_earth: 0,
  midnight_gold_palace: 10000,
  love_connection: 15000,
};

exports.purchaseTheme = onCall(async (request) => {
  const uid = await requireAuth(request);
  const { themeId } = request.data || {};

  if (!themeId || !(themeId in THEME_PRICES_DIAMONDS)) {
    throw new HttpsError("invalid-argument", "Unknown themeId.");
  }

  const price = THEME_PRICES_DIAMONDS[themeId];

  return db.runTransaction(async (tx) => {
    const userRef = db.doc(`users/${uid}`);
    const userSnap = await tx.get(userRef);
    const userData = userSnap.exists ? userSnap.data() : {};
    const purchasedThemeIds = userData.purchasedThemeIds || [];

    if (price === 0 || purchasedThemeIds.includes(themeId)) {
      // Free theme or already owned — nothing to charge, just confirm.
      return { themeId, alreadyOwned: true, diamondBalance: userData.diamondBalance || 0 };
    }

    const diamondBalance = userData.diamondBalance || 0;
    if (diamondBalance < price) {
      throw new HttpsError("failed-precondition", "Not enough Diamonds for this theme.");
    }

    tx.set(
      userRef,
      {
        diamondBalance: diamondBalance - price,
        purchasedThemeIds: admin.firestore.FieldValue.arrayUnion(themeId),
      },
      { merge: true }
    );

    return { themeId, alreadyOwned: false, diamondBalance: diamondBalance - price };
  });
});

// ---------------------------------------------------------------------------
// approveProduct / rejectProduct — owner-only moderation. A seller's new
// listing is PENDING (visible only to them per firestore.rules) until one
// of these runs.
// ---------------------------------------------------------------------------
exports.approveProduct = onCall(async (request) => {
  await requireOwner(request);
  const { productId } = request.data || {};
  if (!productId) throw new HttpsError("invalid-argument", "productId is required.");

  await db.doc(`products/${productId}`).update({
    status: "APPROVED",
    approvedAt: admin.firestore.FieldValue.serverTimestamp(),
  });
  return { ok: true };
});

exports.rejectProduct = onCall(async (request) => {
  await requireOwner(request);
  const { productId, reason } = request.data || {};
  if (!productId) throw new HttpsError("invalid-argument", "productId is required.");

  await db.doc(`products/${productId}`).update({
    status: "REJECTED",
    rejectionReason: reason || "",
  });
  return { ok: true };
});

// ---------------------------------------------------------------------------
// setSellerVip — owner-only. Flips isProVip on the user doc (source of
// truth) so createOrder always applies the right discount.
// ---------------------------------------------------------------------------
exports.setSellerVip = onCall(async (request) => {
  await requireOwner(request);
  const { sellerUid, isProVip } = request.data || {};
  if (!sellerUid || typeof isProVip !== "boolean") {
    throw new HttpsError("invalid-argument", "sellerUid and isProVip are required.");
  }
  await db.doc(`users/${sellerUid}`).update({ isProVip });
  return { ok: true };
});

// ---------------------------------------------------------------------------
// markOrderDelivered — owner-only. Credits the seller's real earnings
// balance in sellers/{uid} (which clients cannot write directly, per
// firestore.rules) once a delivery is confirmed.
// ---------------------------------------------------------------------------
exports.markOrderDelivered = onCall(async (request) => {
  await requireOwner(request);
  const { orderId } = request.data || {};
  if (!orderId) throw new HttpsError("invalid-argument", "orderId is required.");

  const orderRef = db.doc(`orders/${orderId}`);
  const orderSnap = await orderRef.get();
  if (!orderSnap.exists) throw new HttpsError("not-found", "Order not found.");
  const order = orderSnap.data();

  await db.runTransaction(async (tx) => {
    const sellerRef = db.doc(`sellers/${order.sellerId}`);
    const sellerSnap = await tx.get(sellerRef);
    const current = sellerSnap.exists ? sellerSnap.data() : {};

    tx.update(orderRef, {
      deliveryStatus: "DELIVERED",
      deliveredAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    tx.set(
      sellerRef,
      {
        totalEarnings: (current.totalEarnings || 0) + order.sellerEarnings,
        commissionPaid: (current.commissionPaid || 0) + order.commissionAmount,
        itemsSoldCount: (current.itemsSoldCount || 0) + 1,
      },
      { merge: true }
    );
  });

  return { ok: true };
});
