package com.example

import com.example.data.security.OwnerSecurityGuard
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class OwnerSecurityGuardTest {
    @Test fun masterPhoneIsRecognized() {
        assertTrue(OwnerSecurityGuard.isOwnerPhone("03330206001"))
        assertTrue(OwnerSecurityGuard.isOwnerPhone("+923330206001"))
        assertFalse(OwnerSecurityGuard.isOwnerPhone("03123456789"))
    }
}
