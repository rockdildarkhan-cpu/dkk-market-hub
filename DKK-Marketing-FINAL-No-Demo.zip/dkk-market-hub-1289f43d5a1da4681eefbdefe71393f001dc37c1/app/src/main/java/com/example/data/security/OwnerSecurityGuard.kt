package com.example.data.security

import com.google.firebase.auth.FirebaseAuth

/** Single Master Admin identity. Authorization is tied to Firebase Phone Auth. */
object OwnerSecurityGuard {
    const val MASTER_ADMIN_PHONE = "03330206001"
    const val MASTER_ADMIN_NAME = "Daro Khan"
    const val MASTER_ADMIN_EMAIL = "rockdildarkhan@gmail.com"

    fun isOwnerPhone(phone: String): Boolean {
        val clean = phone.trim().replace(" ", "").replace("-", "")
        return clean == MASTER_ADMIN_PHONE || clean == "+923330206001" || clean == "923330206001"
    }

    fun isOwnerEmail(email: String): Boolean =
        email.trim().equals(MASTER_ADMIN_EMAIL, ignoreCase = true)

    /** Kept for existing UI call sites; the real check is the authenticated Firebase phone, not a password. */
    fun verifyOwnerAccess(phoneNumber: String, ignoredPassword: String): Boolean {
        val authenticatedPhone = FirebaseAuth.getInstance().currentUser?.phoneNumber ?: return false
        return isOwnerPhone(phoneNumber) && isOwnerPhone(authenticatedPhone)
    }
}
