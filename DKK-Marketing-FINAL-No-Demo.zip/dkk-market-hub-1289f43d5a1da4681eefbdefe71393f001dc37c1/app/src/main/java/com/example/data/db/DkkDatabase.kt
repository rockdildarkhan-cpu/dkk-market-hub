package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.example.data.dao.OrderDao
import com.example.data.dao.ProductDao
import com.example.data.dao.SellerDao
import com.example.data.dao.UserDao
import com.example.data.model.DeliveryStatus
import com.example.data.model.OrderEntity
import com.example.data.model.ProductEntity
import com.example.data.model.SellerApprovalStatus
import com.example.data.model.SellerProfileEntity

class Converters {
    @TypeConverter
    fun fromUserRole(role: UserRole): String = role.name

    @TypeConverter
    fun toUserRole(value: String): UserRole = try {
        UserRole.valueOf(value)
    } catch (e: Exception) {
        UserRole.BUYER
    }

    @TypeConverter
    fun fromDeliveryStatus(status: DeliveryStatus): String = status.name

    @TypeConverter
    fun toDeliveryStatus(value: String): DeliveryStatus = try {
        DeliveryStatus.valueOf(value)
    } catch (e: Exception) {
        DeliveryStatus.PENDING
    }

    @TypeConverter
    fun fromSellerApprovalStatus(status: SellerApprovalStatus): String = status.name

    @TypeConverter
    fun toSellerApprovalStatus(value: String): SellerApprovalStatus = try {
        SellerApprovalStatus.valueOf(value)
    } catch (e: Exception) {
        SellerApprovalStatus.APPROVED
    }
}

@Database(
    entities = [
        UserEntity::class,
        SellerProfileEntity::class,
        ProductEntity::class,
        OrderEntity::class
    ],
    version = 7,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class DkkDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun sellerDao(): SellerDao
    abstract fun productDao(): ProductDao
    abstract fun orderDao(): OrderDao

    companion object {
        @Volatile
        private var INSTANCE: DkkDatabase? = null

        fun getDatabase(context: Context): DkkDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    DkkDatabase::class.java,
                    "dkk_marketing_database"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                INSTANCE = instance
                instance
            }
        }

    }
}
