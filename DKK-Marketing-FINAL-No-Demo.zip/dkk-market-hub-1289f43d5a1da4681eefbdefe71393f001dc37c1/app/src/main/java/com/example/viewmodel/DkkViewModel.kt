package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.DkkDatabase
import com.example.data.firebase.FirebaseSyncManager
import com.example.data.model.AdminOverviewStats
import com.example.data.model.OrderEntity
import com.example.data.model.ProductEntity
import com.example.data.model.ReceiptVaultItem
import com.example.data.model.SellerProfileEntity
import com.example.data.model.UserEntity
import com.example.data.model.UserRole
import com.example.data.repository.DkkRepository
import com.example.data.security.OwnerSecurityGuard
import com.example.data.security.ReceiptsVaultSecurityGuard
import com.example.data.security.SellerSecurityGuard
import com.example.data.firebase.AudioRoom
import com.example.data.firebase.MicSeat
import com.example.data.firebase.RoomParticipant
import com.example.data.firebase.RoomService
import com.example.data.firebase.GlobalGiftBroadcastService
import com.example.data.firebase.GlobalGiftBroadcast
import com.example.data.firebase.UserProfileService
import com.example.data.firebase.awaitTask
import com.google.firebase.functions.FirebaseFunctions
import com.example.data.firebase.RoomStatus
import com.example.data.model.GlobalCommissionConfig
import com.example.data.repository.CommissionCalculator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppNavigationScreen {
    SPLASH,
    AUTH,
    MAIN_APP,
    AUDIO_ROOM
}

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class DkkViewModel(application: Application) : AndroidViewModel(application) {
    private val db = DkkDatabase.getDatabase(application)
    val firebaseSyncManager = FirebaseSyncManager(application)
    val firebaseConnectionState = firebaseSyncManager.connectionState

    private val repository = DkkRepository(
        userDao = db.userDao(),
        sellerDao = db.sellerDao(),
        productDao = db.productDao(),
        orderDao = db.orderDao(),
        firebaseSyncManager = firebaseSyncManager
    )

    private val _showFirebaseDialog = MutableStateFlow(false)
    val showFirebaseDialog: StateFlow<Boolean> = _showFirebaseDialog.asStateFlow()

    init {
        // Production: no local/demo seed data. User data is created only after Firebase Phone OTP.
    }

    fun openFirebaseDialog() {
        _showFirebaseDialog.value = true
        firebaseSyncManager.checkAndInitialize()
    }

    fun closeFirebaseDialog() {
        _showFirebaseDialog.value = false
    }

    fun syncWithFirebaseCloud() {
        viewModelScope.launch {
            _userMessage.value = "Firebase Cloud sync started..."
            val res = repository.syncAllLocalWithFirebase()
            res.onSuccess { msg ->
                _userMessage.value = msg
            }.onFailure { err ->
                _userMessage.value = "Cloud Sync note: ${err.message ?: "Local data intact"}"
            }
        }
    }

    // Live Firebase streams matching React Native AdminHomeScreen
    val pendingSellersLiveCount = firebaseSyncManager.pendingSellersCount
    val pendingProductsLive = firebaseSyncManager.pendingProducts
    val pendingProductsLiveCount = firebaseSyncManager.pendingProductsCount
    val activeTicketsLive = firebaseSyncManager.activeTickets
    val activeTicketsLiveCount = firebaseSyncManager.activeTicketsCount
    val totalPlatformEarningsLive = firebaseSyncManager.totalPlatformEarnings
    val isLoadingLiveStats = firebaseSyncManager.isLoadingLiveStats

    // 🚨 Real-time notification listener streams for Owner / AdminHomeScreen
    val ownerAlerts = firebaseSyncManager.ownerAlerts
    val activeAlertNotification = firebaseSyncManager.latestAlert

    fun dismissAlert(alertId: String) {
        firebaseSyncManager.dismissAlert(alertId)
    }

    fun dismissActiveAlert() {
        firebaseSyncManager.dismissLatestAlert()
    }

    fun clearAllAlerts() {
        firebaseSyncManager.clearAllAlerts()
    }

    fun simulateHighValueProductAlert() {
        firebaseSyncManager.simulateHighValueProductAlert()
    }

    fun simulateUrgentTicketAlert() {
        firebaseSyncManager.simulateUrgentTicketAlert()
    }

    fun approveProductLive(productId: String) {
        viewModelScope.launch {
            val res = firebaseSyncManager.approveProduct(productId)
            res.onSuccess {
                _userMessage.value = "Product check kar ke live publish kar diya gaya hai!"
            }.onFailure { e ->
                _userMessage.value = "Approval error: ${e.message}"
            }
        }
    }

    fun rejectProductLive(productId: String) {
        viewModelScope.launch {
            val res = firebaseSyncManager.rejectProduct(productId)
            res.onSuccess {
                _userMessage.value = "Product listing reject kar di gayi hai."
            }.onFailure { e ->
                _userMessage.value = "Rejection error: ${e.message}"
            }
        }
    }

    fun submitSupportTicket(
        subject: String,
        email: String,
        role: String,
        message: String,
        priority: String = "medium",
        senderName: String = "",
        senderPhone: String = "",
        screenshotUrl: String? = null
    ) {
        viewModelScope.launch {
            val res = firebaseSyncManager.submitSupportTicket(
                subject = subject,
                userEmail = email,
                userRole = role,
                message = message,
                priority = priority,
                senderName = senderName,
                senderPhone = senderPhone,
                screenshotUrl = screenshotUrl
            )
            res.onSuccess {
                _userMessage.value = "Shikayat / Support Request direct DKK MARKETING ko bhej di gayi hai!"
            }.onFailure {
                _userMessage.value = "Failed to submit report: ${it.message}"
            }
        }
    }

    private val _currentScreen = MutableStateFlow(AppNavigationScreen.SPLASH)
    val currentScreen: StateFlow<AppNavigationScreen> = _currentScreen.asStateFlow()

    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _selectedProduct = MutableStateFlow<ProductEntity?>(null)
    val selectedProduct: StateFlow<ProductEntity?> = _selectedProduct.asStateFlow()

    private val _showCheckoutDialog = MutableStateFlow(false)
    val showCheckoutDialog: StateFlow<Boolean> = _showCheckoutDialog.asStateFlow()

    private val _showPostProductDialog = MutableStateFlow(false)
    val showPostProductDialog: StateFlow<Boolean> = _showPostProductDialog.asStateFlow()

    private val _showFaceScanDialog = MutableStateFlow(false)
    val showFaceScanDialog: StateFlow<Boolean> = _showFaceScanDialog.asStateFlow()

    private val _showRoleSwitchDialog = MutableStateFlow(false)
    val showRoleSwitchDialog: StateFlow<Boolean> = _showRoleSwitchDialog.asStateFlow()

    private val _showSupportChatDialog = MutableStateFlow(false)
    val showSupportChatDialog: StateFlow<Boolean> = _showSupportChatDialog.asStateFlow()

    fun openSupportChatDialog() {
        _showSupportChatDialog.value = true
    }

    fun closeSupportChatDialog() {
        _showSupportChatDialog.value = false
    }

    private val _isDarkTheme = MutableStateFlow(false)
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    fun toggleTheme() {
        _isDarkTheme.value = !_isDarkTheme.value
        _userMessage.value = if (_isDarkTheme.value) "Dark Midnight Theme activated" else "Light Emerald Theme activated"
    }

    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    // All Users
    val allUsers: StateFlow<List<UserEntity>> = repository.allUsers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // All Products
    val allProducts: StateFlow<List<ProductEntity>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered Products for Buyer Feed
    val filteredProducts: StateFlow<List<ProductEntity>> = combine(
        allProducts,
        _searchQuery,
        _selectedCategory
    ) { products, query, cat ->
        products.filter { product ->
            val matchesQuery = query.isBlank() ||
                    product.title.contains(query, ignoreCase = true) ||
                    product.category.contains(query, ignoreCase = true) ||
                    product.sellerName.contains(query, ignoreCase = true)
            val matchesCat = cat == "All" || product.category.equals(cat, ignoreCase = true)
            matchesQuery && matchesCat
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Pro VIP priority products
    val proVipProducts: StateFlow<List<ProductEntity>> = repository.proVipProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Current Seller Profile
    val currentSellerProfile: StateFlow<SellerProfileEntity?> = _currentUser.flatMapLatest { user ->
        if (user != null && user.role == UserRole.SELLER) {
            repository.getSellerProfile(user.uid)
        } else {
            flowOf(null)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Seller's own products
    val sellerProducts: StateFlow<List<ProductEntity>> = _currentUser.flatMapLatest { user ->
        if (user != null && user.role == UserRole.SELLER) {
            repository.getProductsBySeller(user.uid)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Buyer Orders
    val buyerOrders: StateFlow<List<OrderEntity>> = _currentUser.flatMapLatest { user ->
        if (user != null) {
            repository.getOrdersByBuyer(user.uid)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Seller Orders
    val sellerOrders: StateFlow<List<OrderEntity>> = _currentUser.flatMapLatest { user ->
        if (user != null && user.role == UserRole.SELLER) {
            repository.getOrdersBySeller(user.uid)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // All Orders (for Admin / System Audit)
    val allOrders: StateFlow<List<OrderEntity>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSellers: StateFlow<List<SellerProfileEntity>> = repository.allSellers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Admin Overview Stats
    val adminOverviewStats: StateFlow<AdminOverviewStats> = repository.adminOverviewStats
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AdminOverviewStats())

    // Pending Seller KYC Approvals
    val pendingSellerApprovals: StateFlow<List<SellerProfileEntity>> = repository.pendingSellerApprovals
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // 📦 Firebase Storage Receipts Vault Items (receipts_vault/) protected by 3.0 MB Security Firewall
    val receiptsVaultItems: StateFlow<List<ReceiptVaultItem>> = firebaseSyncManager.receiptsVaultItems

    // ⚙️ Global Commission Settings (Protected Owner Admin View)
    private val _globalCommissionConfig = MutableStateFlow(CommissionCalculator.config)
    val globalCommissionConfig: StateFlow<GlobalCommissionConfig> = _globalCommissionConfig.asStateFlow()

    fun updateGlobalCommissionConfig(newConfig: GlobalCommissionConfig) {
        CommissionCalculator.updateConfig(newConfig)
        _globalCommissionConfig.value = newConfig
    }

    fun resetGlobalCommissionConfig() {
        CommissionCalculator.resetToDefaults()
        _globalCommissionConfig.value = CommissionCalculator.config
    }

    init {
        // Production mode: never auto-login or seed a privileged account on app startup.
        // Authentication must establish the current user explicitly.
        viewModelScope.launch {
            _currentUser.value = null
        }
    }

    fun setScreen(screen: AppNavigationScreen) {
        _currentScreen.value = screen
    }

    fun logout() {
        _currentUser.value = null
        _currentScreen.value = AppNavigationScreen.AUTH
        _userMessage.value = "Aap kamyabi se log out ho gaye hain (Logged Out)"
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(category: String) {
        _selectedCategory.value = category
    }

    fun selectProduct(product: ProductEntity?) {
        _selectedProduct.value = product
    }

    fun openCheckoutDialog(product: ProductEntity) {
        _selectedProduct.value = product
        _showCheckoutDialog.value = true
    }

    fun closeCheckoutDialog() {
        _showCheckoutDialog.value = false
    }

    fun openPostProductDialog() {
        _showPostProductDialog.value = true
    }

    fun closePostProductDialog() {
        _showPostProductDialog.value = false
    }

    fun openFaceScanDialog() {
        _showFaceScanDialog.value = true
    }

    fun closeFaceScanDialog() {
        _showFaceScanDialog.value = false
    }

    fun openRoleSwitchDialog() {
        _showRoleSwitchDialog.value = true
    }

    fun closeRoleSwitchDialog() {
        _showRoleSwitchDialog.value = false
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    // Role switching is intentionally disabled in production. Roles come from authenticated Firebase profiles.
    fun switchUserPersona(targetRole: UserRole) {
        _userMessage.value = "Role switching is disabled. Please sign in with the correct account."
    }

    // Custom Login / Registration with Phone & OTP (Owner strictly verified by OwnerSecurityGuard)
    fun loginOrRegister(phone: String, name: String, email: String, role: UserRole, firebaseUid: String? = null) {
        viewModelScope.launch {
            val isAuthorizedOwner = OwnerSecurityGuard.isOwnerPhone(phone) || OwnerSecurityGuard.isOwnerEmail(email)
            val finalRole = if (role == UserRole.OWNER && isAuthorizedOwner) UserRole.OWNER else if (role == UserRole.OWNER) UserRole.BUYER else role
            val finalName = if (finalRole == UserRole.OWNER && (name.isBlank() || name == "User")) "Daro Khan (DKK Owner)" else name
            val user = repository.registerOrLoginUser(phone, finalName, email, finalRole, firebaseUid)
            _currentUser.value = user
            if (finalRole == UserRole.SELLER) {
                val seller = repository.getSellerProfileDirect(user.uid)
                _currentScreen.value = AppNavigationScreen.MAIN_APP
                if (seller?.faceScanVerified != true) {
                    _showFaceScanDialog.value = true
                }
            } else {
                _currentScreen.value = AppNavigationScreen.MAIN_APP
            }
            _userMessage.value = "Welcome ${user.name} (${user.role.displayName})"
        }
    }

    // =========================================================================
    // REAL FIREBASE PHONE-OTP LOGIN
    // =========================================================================
    private val _isBootstrappingProfile = MutableStateFlow(false)
    val isBootstrappingProfile: StateFlow<Boolean> = _isBootstrappingProfile.asStateFlow()

    /**
     * Call this right after PhoneOtpAuthScreen reports a verified phone +
     * Firebase uid. It calls the bootstrapUserProfile Cloud Function (which
     * reads Firebase's own verified phone claim — never trusts the client
     * for role assignment), then feeds the result through the existing
     * local login flow so the rest of the app keeps working unchanged, now
     * backed by a real Firebase-authenticated account.
     */
    fun completeOtpLogin(phoneE164: String, firebaseUid: String) {
        viewModelScope.launch {
            _isBootstrappingProfile.value = true
            try {
                val data = hashMapOf(
                    "fallbackName" to "DKK User",
                    "fallbackEmail" to ""
                )
                val result = FirebaseFunctions.getInstance()
                    .getHttpsCallable("bootstrapUserProfile")
                    .call(data)
                    .awaitTask()

                @Suppress("UNCHECKED_CAST")
                val resultData = result.data as? Map<String, Any?>
                val roleStr = resultData?.get("role") as? String ?: "BUYER"
                val role = try { UserRole.valueOf(roleStr) } catch (_: Exception) { UserRole.BUYER }

                // Local phone format used elsewhere in the app is "03XXXXXXXXX".
                val localPhone = "0" + phoneE164.removePrefix("+92")
                val displayName = when (role) {
                    UserRole.OWNER -> "Daro Khan (DKK Owner)"
                    else -> "DKK User"
                }

                loginOrRegister(localPhone, displayName, "", role, firebaseUid)
            } catch (e: Exception) {
                _userMessage.value = "❌ Profile setup failed: ${e.message ?: "please try again"}"
            } finally {
                _isBootstrappingProfile.value = false
            }
        }
    }

    // Easypaisa Order Placement
    fun processEasypaisaPayment(product: ProductEntity, paymentRef: String) {
        viewModelScope.launch {
            val user = _currentUser.value ?: return@launch
            val order = repository.placeEasypaisaOrder(
                buyerId = user.uid,
                buyerPhone = user.phoneNumber,
                product = product,
                paymentRef = paymentRef
            )
            _showCheckoutDialog.value = false
            _selectedProduct.value = null
            _userMessage.value = "Order ${order.orderId} placed. Delivery OTP is available only in your order details."
        }
    }

    // Post Product Listing
    fun postNewProduct(
        title: String,
        description: String,
        price: Double,
        category: String,
        isProVip: Boolean,
        imageUrl: String = "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&auto=format&fit=crop&q=80",
        isFreeDelivery: Boolean = true,
        deliveryFee: Double = 0.0
    ) {
        viewModelScope.launch {
            val user = _currentUser.value ?: return@launch
            val seller = currentSellerProfile.value
            val sellerName = seller?.businessName ?: user.name

            val finalImageUrl = if (imageUrl.isNotBlank()) imageUrl else "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&auto=format&fit=crop&q=80"

            repository.createProduct(
                sellerId = user.uid,
                sellerName = sellerName,
                title = title,
                description = description,
                price = price,
                category = category,
                imageUrl = finalImageUrl,
                isProVip = isProVip,
                isFreeDelivery = isFreeDelivery,
                deliveryFee = deliveryFee
            )
            _showPostProductDialog.value = false
            _userMessage.value = "Product '$title' published successfully!"
        }
    }

    // Complete Seller Face Scan
    fun completeFaceScan() {
        viewModelScope.launch {
            val user = _currentUser.value ?: return@launch
            repository.submitFaceScanVerification(user.uid)
            _showFaceScanDialog.value = false
            _userMessage.value = "Face Scan 100% Verified! Seller Dashboard Active."
        }
    }

    // Dispatch Order
    fun dispatchOrder(orderId: String) {
        viewModelScope.launch {
            repository.dispatchOrder(orderId)
            _userMessage.value = "Order marked as Dispatched!"
        }
    }

    // Deliver Order with OTP
    fun verifyAndDeliverOrder(orderId: String, otp: String) {
        viewModelScope.launch {
            val success = repository.completeOrderDelivery(orderId, otp)
            if (success) {
                _userMessage.value = "Delivery Completed! Auto-Commission calculated & Seller Level updated!"
            } else {
                _userMessage.value = "Incorrect Delivery OTP code. Please retry."
            }
        }
    }

    // Owner Actions
    fun approveSeller(sellerId: String) {
        viewModelScope.launch {
            repository.approveSellerKYC(sellerId)
            _userMessage.value = "Seller KYC Approved!"
        }
    }

    fun rejectSeller(sellerId: String) {
        viewModelScope.launch {
            repository.rejectSellerKYC(sellerId)
            _userMessage.value = "Seller KYC Rejected."
        }
    }

    fun toggleProVip(uid: String, enable: Boolean) {
        viewModelScope.launch {
            repository.toggleProVipSubscription(uid, enable)
            _userMessage.value = if (enable) "Pro VIP Subscription Activated (Fee: Rs 5,000)" else "Pro VIP Disabled"
        }
    }

    // 💰 Seller Payout Accounts (Bank Details & Easypaisa Number)
    fun updateSellerPayoutDetails(
        bankName: String,
        accountTitle: String,
        accountNumber: String,
        iban: String,
        easypaisaNumber: String,
        easypaisaTitle: String
    ) {
        viewModelScope.launch {
            val user = _currentUser.value ?: return@launch
            repository.updateSellerPayoutDetails(
                uid = user.uid,
                bankName = bankName,
                bankAccountTitle = accountTitle,
                bankAccountNumber = accountNumber,
                bankIban = iban,
                easypaisaNumber = easypaisaNumber,
                easypaisaTitle = easypaisaTitle
            )
            _userMessage.value = "Bank aur Easypaisa details save ho gayi hain! Amount Friday ko send hogi."
        }
    }

    // 📦 Upload Receipt / Screenshot to receipts_vault/ under 3.0 MB Security Firewall
    fun uploadReceiptToVault(
        title: String,
        slipType: String,
        referenceId: String,
        amount: Double,
        fileSizeBytes: Long,
        imageUrl: String
    ): Boolean {
        val user = _currentUser.value
        val result = firebaseSyncManager.uploadReceiptToVault(
            title = title,
            senderName = user?.name ?: "User",
            senderPhone = user?.phoneNumber.orEmpty(),
            senderRole = user?.role?.name?.lowercase() ?: "buyer",
            slipType = slipType,
            referenceId = referenceId,
            amount = amount,
            fileSizeBytes = fileSizeBytes,
            imageUrl = imageUrl
        )
        return if (result.isSuccess) {
            _userMessage.value = "Screenshot 'receipts_vault/' mein mehfooz ho gaya! (Firewall Passed ✓)"
            true
        } else {
            _userMessage.value = result.exceptionOrNull()?.message ?: "Upload failed"
            false
        }
    }

    // 👑 Owner Verification of Receipt Slip on Everything Clear Dashboard
    fun verifyReceiptSlip(slipId: String) {
        firebaseSyncManager.verifyReceiptSlip(slipId)
        _userMessage.value = "Receipt Slip Verified & Cleared on Everything Clear Dashboard ✓"
    }

    fun rejectReceiptSlip(slipId: String) {
        firebaseSyncManager.rejectReceiptSlip(slipId)
        _userMessage.value = "Receipt Slip Rejected."
    }

    // 🔄 Buyer 2-Day Return Guarantee Window Request
    fun requestOrderReturn(
        orderId: String,
        reason: String,
        proofScreenshotUrl: String,
        fileSizeBytes: Long = 1_500_000L
    ) {
        viewModelScope.launch {
            val result = repository.requestBuyerOrderReturn(
                orderId = orderId,
                reason = reason,
                proofScreenshotUrl = proofScreenshotUrl,
                fileSizeBytes = fileSizeBytes
            )
            if (result.isSuccess) {
                _userMessage.value = "Wapsi ki darkhwast aur saboot receipts_vault/ mein bhej diya gaya hai! (2-Day Window Active)"
            } else {
                _userMessage.value = result.exceptionOrNull()?.message ?: "Wapsi darkhwast darj nahi ho saki."
            }
        }
    }

    // 🗓️ Friday Payout Clearance System (جمعہ پے آؤٹ کلیئرنس)
    fun clearSellerFridayPayout(sellerId: String, amount: Double) {
        viewModelScope.launch {
            val result = repository.clearSellerFridayPayout(sellerId, amount)
            if (result.isSuccess) {
                _userMessage.value = "🗓️ Jumma Payout Rs ${amount.toInt()} seller ke account mein transfer aur clear ho gaya!"
            } else {
                _userMessage.value = "Payout clear nahi ho saka: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    fun clearAllFridayPayouts(totalAmount: Double) {
        viewModelScope.launch {
            val result = repository.clearAllFridayPayouts(totalAmount)
            if (result.isSuccess) {
                _userMessage.value = "🚀 Tamam sellers ko Jumma Payout (Rs ${totalAmount.toInt()}) kamyabi se transfer aur clear ho gaya!"
            } else {
                _userMessage.value = "Payouts clear nahi ho sake: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    // =========================================================================
    // 🎙️ D.K.K. 5-MIC SOCIAL AUDIO LOUNGE & VIP STREAMING SYSTEM
    // =========================================================================
    val roomService = RoomService()

    private val _isAudioRoomOpen = MutableStateFlow(false)
    val isAudioRoomOpen: StateFlow<Boolean> = _isAudioRoomOpen.asStateFlow()

    private val _coinBalance = MutableStateFlow(85_000L) // Starting test coin balance
    val coinBalance: StateFlow<Long> = _coinBalance.asStateFlow()

    private val _diamondBalance = MutableStateFlow(0L) // Real Host Diamond/Bean wallet
    val diamondBalance: StateFlow<Long> = _diamondBalance.asStateFlow()

    private val _allAudioRooms = MutableStateFlow<List<AudioRoom>>(emptyList())
    val allAudioRooms: StateFlow<List<AudioRoom>> = _allAudioRooms.asStateFlow()

    private val _activeRoom = MutableStateFlow(
        AudioRoom(
            roomId = "room_6974202528",
            title = "🦅 خوږه یاران 👑",
            hostUid = "host_6974202528",
            hostName = "Rafi Host",
            hostAvatar = "",
            countryFlag = "🇦🇪",
            countryName = "UAE",
            status = RoomStatus.LIVE,
            listenerCount = 1,
            seats = (0 until AudioRoom.MAX_MIC_SEATS).map { idx ->
                when (idx) {
                    0 -> MicSeat(
                        seatIndex = 0,
                        occupantUid = "host_6974202528",
                        occupantName = "Rafi Host",
                        isMuted = false,
                        isTalking = true,
                        giftScore = 0L,
                        joinedAt = System.currentTimeMillis()
                    )
                    else -> MicSeat(seatIndex = idx, isLocked = false)
                }
            },
            videoStreamUrl = null,
            isVideoLoopActive = false,
            totalCoinsGifted = 0L,
            roomLevel = 1
        )
    )
    val activeRoom: StateFlow<AudioRoom> = _activeRoom.asStateFlow()

    // Music Player State for Audio Room (As shown in user screenshots)
    private val _isPlayingMusic = MutableStateFlow(false)
    val isPlayingMusic: StateFlow<Boolean> = _isPlayingMusic.asStateFlow()

    private val _broadcastMyMusic = MutableStateFlow(false)
    val broadcastMyMusic: StateFlow<Boolean> = _broadcastMyMusic.asStateFlow()

    private val _currentTrack = MutableStateFlow("naya_daur")
    val currentTrack: StateFlow<String> = _currentTrack.asStateFlow()

    private val _musicProgress = MutableStateFlow(0.45f) // ~01:14 of 02:43
    val musicProgress: StateFlow<Float> = _musicProgress.asStateFlow()

    fun togglePlayMusic() {
        _isPlayingMusic.value = !_isPlayingMusic.value
    }

    fun toggleBroadcastMyMusic() {
        _broadcastMyMusic.value = !_broadcastMyMusic.value
    }

    private val _latestGiftAnimation = MutableStateFlow<String?>(null)
    val latestGiftAnimation: StateFlow<String?> = _latestGiftAnimation.asStateFlow()

    // "Big gift" banners (e.g. BiG BOSS sending Everyone a gift) that show
    // in EVERY room, not just the one the gift was sent in. Fed by
    // GlobalGiftBroadcastService, which streams from the globalGiftBroadcasts
    // collection written by the sendRoomGift Cloud Function.
    private val globalGiftBroadcastService = GlobalGiftBroadcastService()
    private val _globalGiftBanner = MutableStateFlow<GlobalGiftBroadcast?>(null)
    val globalGiftBanner: StateFlow<GlobalGiftBroadcast?> = _globalGiftBanner.asStateFlow()

    init {
        viewModelScope.launch {
            globalGiftBroadcastService.observeLatestBroadcast().collect { broadcast ->
                _globalGiftBanner.value = broadcast
                delay(6000)
                if (_globalGiftBanner.value?.id == broadcast.id) {
                    _globalGiftBanner.value = null
                }
            }
        }
        // Live room lobby, straight from Firestore — every device sees the
        // same rooms as soon as they're created.
        viewModelScope.launch {
            roomService.observeLiveRooms().collect { rooms ->
                _allAudioRooms.value = rooms
            }
        }
        // Coin/Diamond balance and owned themes — real-time from
        // users/{uid}, kept accurate by the sendRoomGift/purchaseTheme
        // Cloud Functions rather than trusted from the client.
        viewModelScope.launch {
            _currentUser.collect { user ->
                walletListenerJob?.cancel()
                if (user != null && user.uid.isNotBlank()) {
                    walletListenerJob = launch {
                        userProfileService.observeWallet(user.uid).collect { wallet ->
                            _coinBalance.value = wallet.coinBalance
                            _diamondBalance.value = wallet.diamondBalance
                            _unlockedThemes.value = wallet.purchasedThemeIds + "cosmic_earth"
                        }
                    }
                }
            }
        }
    }

    private var activeRoomListenerJob: kotlinx.coroutines.Job? = null
    private var walletListenerJob: kotlinx.coroutines.Job? = null
    private val userProfileService = UserProfileService()

    /** Opens a room by id and keeps it live-updated from Firestore (seats, gifting total, level, theme...). */
    private fun openRoomById(roomId: String) {
        activeRoomListenerJob?.cancel()
        activeRoomListenerJob = viewModelScope.launch {
            roomService.observeRoom(roomId).collect { room ->
                if (room != null) {
                    _activeRoom.value = room
                }
            }
        }
        _isAudioRoomOpen.value = true
        _currentScreen.value = AppNavigationScreen.AUDIO_ROOM
    }

    fun openAudioRoom() {
        val existing = _allAudioRooms.value.firstOrNull()
        if (existing != null) {
            openRoomById(existing.roomId)
        } else {
            val user = currentUser.value
            val hostName = user?.name ?: "Host"
            createNewRoom(title = "$hostName's Audio Lounge", videoStreamUrl = null)
        }
    }

    fun selectAndOpenRoom(room: AudioRoom) {
        openRoomById(room.roomId)
    }

    /**
     * Creates (or re-opens) this user's one room via the trusted
     * createOrGetMyRoom Cloud Function — server-assigned room id ("001" =
     * official room numbering is generated from live room data), real 5-seat
     * layout, synced to every device through Firestore.
     */
    fun createNewRoom(
        title: String,
        videoStreamUrl: String? = null,
        countryFlag: String = "🇦🇫",
        countryName: String = "Afghanistan"
    ) {
        val user = currentUser.value
        if (user == null) {
            _userMessage.value = "❌ Room banane ke liye pehle login karein."
            return
        }
        viewModelScope.launch {
            val result = roomService.createOrGetMyRoom(
                title = title,
                hostName = user.name,
                hostAvatar = user.profilePicture
            )
            result.onSuccess { roomId ->
                openRoomById(roomId)
                _userMessage.value = "🎙️ Room ready! Aap Mic Seat 1 (Host) par hain."
            }.onFailure { e ->
                _userMessage.value = "❌ Room nahi ban saka: ${e.message ?: "please try again"}"
            }
        }
    }

    fun closeAudioRoom() {
        activeRoomListenerJob?.cancel()
        _isAudioRoomOpen.value = false
        _currentScreen.value = AppNavigationScreen.MAIN_APP
        // Decrement listener count
        val curUser = currentUser.value
        val curSeats = _activeRoom.value.seats.toMutableList()
        if (curUser != null) {
            val idx = curSeats.indexOfFirst { it.occupantUid == curUser.uid }
            if (idx != -1) {
                curSeats[idx] = MicSeat(seatIndex = idx)
            }
        }
        _activeRoom.value = _activeRoom.value.copy(
            listenerCount = (_activeRoom.value.listenerCount - 1).coerceAtLeast(1),
            seats = curSeats
        )
    }

    fun occupyMicSeat(seatIndex: Int) {
        val curUser = currentUser.value ?: return
        val currentSeats = _activeRoom.value.seats.toMutableList()

        if (seatIndex !in 0 until AudioRoom.MAX_MIC_SEATS) return

        if (currentSeats[seatIndex].isLocked) {
            _userMessage.value = "🔒 Yeh Seat locked hai. Sirf Host isko unlock kar sakta hai."
            return
        }

        // Check if user already on another seat
        val existingIndex = currentSeats.indexOfFirst { it.occupantUid == curUser.uid }
        if (existingIndex != -1) {
            _userMessage.value = "Aap pehle hi Mic Seat ${existingIndex + 1} par baithe hain!"
            return
        }

        if (currentSeats[seatIndex].isOccupied) {
            _userMessage.value = "Mic Seat ${seatIndex + 1} pehle se kisi aur ke pas hai."
            return
        }

        currentSeats[seatIndex] = MicSeat(
            seatIndex = seatIndex,
            occupantUid = curUser.uid,
            occupantName = curUser.name,
            occupantAvatar = "",
            isMuted = false,
            isTalking = false,
            isLocked = false,
            giftScore = 0L,
            joinedAt = System.currentTimeMillis()
        )

        _activeRoom.value = _activeRoom.value.copy(seats = currentSeats)
        _userMessage.value = "🎙️ Mubarak! Aap Mic Seat ${seatIndex + 1} par live aa gaye!"
    }

    fun leaveMicSeat(seatIndex: Int) {
        val curUser = currentUser.value ?: return
        val currentSeats = _activeRoom.value.seats.toMutableList()

        if (seatIndex !in 0 until AudioRoom.MAX_MIC_SEATS) return
        val seat = currentSeats[seatIndex]

        if (seat.occupantUid == curUser.uid || curUser.role == UserRole.OWNER || curUser.uid == _activeRoom.value.hostUid) {
            currentSeats[seatIndex] = MicSeat(seatIndex = seatIndex, isLocked = seat.isLocked)
            _activeRoom.value = _activeRoom.value.copy(seats = currentSeats)
            _userMessage.value = "Aap Mic Seat ${seatIndex + 1} se audience mein wapis aagaye."
        }
    }

    fun toggleMicSeatMute(seatIndex: Int) {
        val curUser = currentUser.value ?: return
        val currentSeats = _activeRoom.value.seats.toMutableList()

        if (seatIndex !in 0 until AudioRoom.MAX_MIC_SEATS) return
        val seat = currentSeats[seatIndex]

        if (seat.occupantUid == curUser.uid || curUser.role == UserRole.OWNER || curUser.uid == _activeRoom.value.hostUid) {
            val newMute = !seat.isMuted
            currentSeats[seatIndex] = seat.copy(isMuted = newMute)
            _activeRoom.value = _activeRoom.value.copy(seats = currentSeats)
            _userMessage.value = if (newMute) "Mic Muted 🔇" else "Mic Live & Unmuted 🎙️"
        }
    }

    fun toggleSeatLock(seatIndex: Int) {
        if (seatIndex !in 0 until AudioRoom.MAX_MIC_SEATS) return
        val curUser = currentUser.value
        val isHostOrOwner = curUser == null || curUser.role == UserRole.OWNER || curUser.uid == _activeRoom.value.hostUid
        if (isHostOrOwner) {
            val currentSeats = _activeRoom.value.seats.toMutableList()
            val seat = currentSeats[seatIndex]
            val newLock = !seat.isLocked
            currentSeats[seatIndex] = seat.copy(isLocked = newLock)
            _activeRoom.value = _activeRoom.value.copy(seats = currentSeats)
            _userMessage.value = if (newLock) "🔒 Seat ${seatIndex + 1} Locked" else "🔓 Seat ${seatIndex + 1} Unlocked"
        } else {
            _userMessage.value = "Sirf Host ya Admin hi Seat lock/unlock kar sakta hai."
        }
    }

    fun updateUserProfile(name: String, phoneNumber: String, profilePicture: String = "") {
        val curUser = _currentUser.value
        val updatedUser = (curUser ?: UserEntity(
            uid = "user_guest",
            phoneNumber = phoneNumber,
            email = "",
            name = name,
            profilePicture = profilePicture,
            role = UserRole.BUYER
        )).copy(
            name = name,
            phoneNumber = phoneNumber,
            profilePicture = if (profilePicture.isNotBlank()) profilePicture else (curUser?.profilePicture ?: "")
        )
        _currentUser.value = updatedUser
        viewModelScope.launch {
            try {
                repository.updateUserProfile(updatedUser.uid, name, phoneNumber, profilePicture)
            } catch (e: Exception) {
                // Ignore local fallback error
            }
        }
        _userMessage.value = "Profile updated: $name ✅"
    }

    // Room Themes State (Cosmic Earth & Moon is 1st Free Default theme from uploaded photo)
    private val _unlockedThemes = MutableStateFlow<Set<String>>(setOf("cosmic_earth", "dark_slate"))
    val unlockedThemes: StateFlow<Set<String>> = _unlockedThemes.asStateFlow()

    fun updateRoomSettings(
        newTitle: String = "",
        newCountryFlag: String = "",
        newDpUrl: String = "",
        newBannerUrl: String = "",
        newAnnouncement: String = "",
        newThemeId: String = ""
    ) {
        val current = _activeRoom.value
        val updated = current.copy(
            title = if (newTitle.isNotBlank()) newTitle else current.title,
            countryFlag = if (newCountryFlag.isNotBlank()) newCountryFlag else current.countryFlag,
            hostAvatar = if (newDpUrl.isNotBlank()) newDpUrl else current.hostAvatar,
            roomDpUrl = if (newDpUrl.isNotBlank()) newDpUrl else current.roomDpUrl,
            roomBannerUrl = if (newBannerUrl.isNotBlank()) newBannerUrl else current.roomBannerUrl,
            announcement = if (newAnnouncement.isNotBlank()) newAnnouncement else current.announcement,
            themeId = if (newThemeId.isNotBlank()) newThemeId else current.themeId
        )
        _activeRoom.value = updated
        val list = _allAudioRooms.value.toMutableList()
        val idx = list.indexOfFirst { it.roomId == updated.roomId }
        if (idx != -1) {
            list[idx] = updated
            _allAudioRooms.value = list
        }
        _userMessage.value = "Room settings updated successfully! 👑"
    }

    fun purchaseAndApplyTheme(themeId: String, cost: Long) {
        val room = _activeRoom.value
        if (room.roomId.isBlank()) {
            _userMessage.value = "❌ Pehle apna room khulwayein."
            return
        }
        if (cost > 0 && _diamondBalance.value < cost) {
            _userMessage.value = "❌ Diamonds kam hain! Is theme ke liye $cost Diamonds darkar hain."
            return
        }
        viewModelScope.launch {
            val result = roomService.purchaseAndApplyTheme(room.roomId, themeId)
            result.onSuccess {
                _unlockedThemes.value = _unlockedThemes.value + themeId
                _userMessage.value = if (cost > 0) {
                    "🎨 Theme unlocked and applied! (-$cost 💎 Diamonds)"
                } else {
                    "🎨 Room Theme applied!"
                }
                // diamondBalance updates automatically via the users/{uid}
                // profile listener; activeRoom.themeId updates via observeRoom.
            }.onFailure { e ->
                _userMessage.value = "❌ Theme apply nahi ho saka: ${e.message ?: "please try again"}"
            }
        }
    }

    // Real-time VIP Video Daily Quota: 12 videos/day for Room VIP, 15 sec max, auto-deletes in 1 hour
    private val _vipVideosUploadedToday = MutableStateFlow(3)
    val vipVideosUploadedToday: StateFlow<Int> = _vipVideosUploadedToday.asStateFlow()

    fun uploadVipHighlightVideo(title: String = "15-Sec Voice & Highlight") {
        if (_vipVideosUploadedToday.value >= 12) {
            _userMessage.value = "⚠️ Daily VIP Quota reached (12/12)! Kal dobara upload karein."
            return
        }
        _vipVideosUploadedToday.value += 1
        _userMessage.value = "🎥 VIP Video highlight '$title' posted! (${_vipVideosUploadedToday.value}/12 Today • 1-hr auto-delete)"
    }

    fun canUserPayout(user: UserEntity? = currentUser.value): Boolean {
        val curUser = user ?: currentUser.value ?: return false
        return curUser.role == UserRole.OWNER || curUser.uid == _activeRoom.value.hostUid
    }

    // VIP Subscriptions: Type 1 = ROOM VIP ($100/mo, 12 videos/day, max 15s, 1-hr delete), Type 2 = SELLER VIP (3 PIV tag media, 5 videos/day on home)
    private val _isRoomVip = MutableStateFlow(true) // default unlocked for demo/testing
    val isRoomVip: StateFlow<Boolean> = _isRoomVip.asStateFlow()

    private val _isSellerVip = MutableStateFlow(true)
    val isSellerVip: StateFlow<Boolean> = _isSellerVip.asStateFlow()

    fun subscribeRoomVip() {
        _isRoomVip.value = true
        _userMessage.value = "🌟 Room VIP Active ($100/mo)! Daily 12 videos (15 sec, 1-hr auto-delete) post kar sakte hain!"
    }

    fun subscribeSellerVip() {
        _isSellerVip.value = true
        _userMessage.value = "💎 Seller VIP Active! 3 PIV Tag Photos/Videos aur Daily 5 Home Videos quota unlock ho gaya!"
    }

    private val _giftRedemptions = MutableStateFlow<List<PhysicalGiftRedemption>>(
        listOf(
            PhysicalGiftRedemption(
                itemTitle = "Pakistani Designer Silk Bridal Suit 👗",
                diamondsSpent = 15000L,
                recipientName = "Ayesha Khan",
                phone = "0301-7654321",
                city = "Lahore",
                fullAddress = "House 14, Block C, Gulberg III, Lahore",
                status = "Dispatched via DKK Express 🚚"
            )
        )
    )
    val giftRedemptions: StateFlow<List<PhysicalGiftRedemption>> = _giftRedemptions.asStateFlow()

    fun sendLuxuryGift(targetRecipient: String = "Host", giftId: String, giftName: String, coinPrice: Long) {
        val curUser = currentUser.value ?: return
        val room = _activeRoom.value

        // Resolve the real recipient uid: try to match a seated speaker by
        // name, otherwise default to the room host (matches the UI's
        // "Host (...)" default selection).
        val recipientUid = room.seats
            .firstOrNull { it.occupantUid != null && targetRecipient.contains(it.occupantName) }
            ?.occupantUid
            ?: room.hostUid

        if (recipientUid.isBlank()) {
            _userMessage.value = "❌ Is room ka host abhi set nahi hai."
            return
        }

        viewModelScope.launch {
            val result = roomService.sendGift(
                roomId = room.roomId,
                recipientUid = recipientUid,
                giftName = giftName,
                coinPrice = coinPrice
            )
            result.onSuccess { gift ->
                val banner = "${curUser.name} ne $targetRecipient ko $giftName ($coinPrice Coins) gift kiya! 🎁✨ (30% Share: ${gift.diamondsEarned} Diamonds)"
                _latestGiftAnimation.value = banner
                _userMessage.value = if (gift.leveledUp) {
                    "🎉 Room ne 10M Diamonds cross kar liye — Level 2 unlock ho gaya! 👑"
                } else {
                    banner
                }
                // coinBalance/diamondBalance update automatically via the
                // users/{uid} profile listener; activeRoom updates via
                // observeRoom — no local mutation needed here.
            }.onFailure { e ->
                val msg = e.message ?: ""
                _userMessage.value = if (msg.contains("Not enough coins", ignoreCase = true)) {
                    "❌ Coins kam hain! Coin Shop se mazeed coins hasil karein."
                } else {
                    "❌ Gift bhejna nakaam raha: $msg"
                }
            }
        }
    }

    fun sendLuxuryGift(giftId: String, giftName: String, coinPrice: Long) {
        sendLuxuryGift(targetRecipient = "Host", giftId = giftId, giftName = giftName, coinPrice = coinPrice)
    }

    fun clearGiftAnimation() {
        _latestGiftAnimation.value = null
    }

    // Pakistan Coin Purchase: 5,000 PKR = 5,000 Coins (1 PKR = 1 Coin)
    fun topUpCoinsPakistan(coinAmount: Long, pkrAmount: Long, paymentMethod: String = "Easypaisa / JazzCash") {
        _coinBalance.value += coinAmount
        _userMessage.value = "🪙 Pakistan Top-Up Kamyab! $coinAmount Coins wallet mein shamil! (Rs $pkrAmount - $paymentMethod) [Rate: 1 PKR = 1 Coin]"
    }

    fun topUpCoinsPakistan(coinAmount: Long, pkrAmount: Double, paymentMethod: String = "Easypaisa / JazzCash") {
        topUpCoinsPakistan(coinAmount, pkrAmount.toLong(), paymentMethod)
    }

    // Overseas / Website Coin Purchase: $50 USD = 5,000 Coins ($10 = 1000, $50 = 5000, $100 = 10000)
    fun topUpCoinsOverseas(coinAmount: Long, usdAmount: Long, paymentMethod: String = "Website Direct Portal") {
        _coinBalance.value += coinAmount
        _userMessage.value = "🪙 Overseas Direct Top-Up Kamyab! $coinAmount Coins wallet mein shamil! ($$usdAmount USD - $paymentMethod) [Rate: $50 = 5,000 Coins]"
    }

    fun topUpCoinsOverseas(coinAmount: Long, usdAmount: Double, paymentMethod: String = "Website Direct Portal") {
        topUpCoinsOverseas(coinAmount, usdAmount.toLong(), paymentMethod)
    }

    fun topUpCoins(coinAmount: Long, pkrAmount: Double, paymentMethod: String = "Easypaisa / JazzCash") {
        topUpCoinsPakistan(coinAmount, pkrAmount.toLong(), paymentMethod)
    }

    // Friday to Friday 30% Diamond Cashout: ONLY Host or Room Admin authorized
    fun cashoutDiamonds(
        diamondAmount: Long,
        payoutMethod: String = "Friday Direct Transfer",
        accountNumber: String = "0327-3856001",
        user: UserEntity? = null,
        accountDetails: String? = null
    ) {
        val acc = accountDetails ?: accountNumber
        if (!canUserPayout(user)) {
            _userMessage.value = "❌ Payout sirf Room Host ya Admin kar sakte hain!"
            return
        }
        if (_diamondBalance.value < diamondAmount) {
            _userMessage.value = "❌ Diamonds kam hain! Maujuda balance: ${_diamondBalance.value}"
            return
        }
        // 30% Earning weekly Friday-to-Friday payout
        val pkrValue = diamondAmount // 1 Diamond = 1 PKR in 30% share
        _diamondBalance.value -= diamondAmount
        _userMessage.value = "💸 30% Host Payout: Rs $pkrValue $payoutMethod ($acc) par scheduled! (Friday to Friday Clearance Cycle)"
    }

    // Physical Luxury Gift Redemption (Dress, Makeup, Watch, etc. delivered in Pakistan)
    fun redeemDiamondsForPhysicalGift(
        itemTitle: String,
        diamondsCost: Long,
        recipientName: String,
        phone: String,
        city: String,
        fullAddress: String
    ) {
        if (_diamondBalance.value < diamondsCost) {
            _userMessage.value = "❌ Diamonds kam hain! Is gift ke liye $diamondsCost Diamonds darkar hain."
            return
        }
        _diamondBalance.value -= diamondsCost
        val redemption = PhysicalGiftRedemption(
            itemTitle = itemTitle,
            diamondsSpent = diamondsCost,
            recipientName = recipientName,
            phone = phone,
            city = city,
            fullAddress = fullAddress
        )
        _giftRedemptions.value = listOf(redemption) + _giftRedemptions.value
        _userMessage.value = "🎁 Mubarak! '$itemTitle' order ho gaya! Pakistan address ($city, $phone) par DKK Courier deliver karega."
    }

    fun redeemPhysicalGift(
        giftTitle: String = "",
        diamondCost: Long = 0L,
        recipientName: String,
        phone: String,
        city: String,
        fullAddress: String,
        itemTitle: String = giftTitle,
        diamondsCost: Long = diamondCost
    ) {
        val title = if (giftTitle.isNotBlank()) giftTitle else itemTitle
        val cost = if (diamondCost > 0L) diamondCost else diamondsCost
        redeemDiamondsForPhysicalGift(title, cost, recipientName, phone, city, fullAddress)
    }

    // Upload Pre-Recorded Brand Video (ROOM VIP: 12 videos/day, max 15s, auto-deletes in 1 hour; SELLER VIP: 5 videos/day on Home)
    fun uploadPreRecordedVideo(title: String, durationMinutes: Int, isVipTier: Boolean) {
        val maxUploads = if (isVipTier) 12 else 5
        _activeRoom.value = _activeRoom.value.copy(
            videoStreamUrl = "https://stream.cloudflare.com/vip_$title.m3u8",
            isVideoLoopActive = true
        )
        _userMessage.value = "🎥 Video '$title' Room VIP stream loop mein shamil ho gayi! (15-Sec Story, 1 Hour mein auto-delete hogi • Daily Quota: $maxUploads videos)"
    }
}

/**
 * Physical Luxury Gift Delivery record (e.g. Dress, Makeup, Watch)
 */
data class PhysicalGiftRedemption(
    val id: String = java.util.UUID.randomUUID().toString(),
    val itemTitle: String,
    val diamondsSpent: Long,
    val recipientName: String,
    val phone: String,
    val city: String,
    val fullAddress: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "Dispatching via DKK Courier 🚚"
)
