package com.example.data.security

/** Production seller helpers. Seller identity comes from Firebase Authentication. */
object SellerSecurityGuard {
    fun normalizePhone(phone: String): String {
        val clean = phone.trim().replace(" ", "").replace("-", "")
        return if (clean.startsWith("+92")) "0" + clean.removePrefix("+92")
        else if (clean.startsWith("92") && clean.length == 12) "0" + clean.removePrefix("92")
        else clean
    }
}
